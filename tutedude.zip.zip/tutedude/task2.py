first_name=input("Enter the first name: ")
last_name=input("Enter the last name: ")
full_name=first_name+" "+last_name
print(f"Hello,{full_name}!Welcome to Python!")